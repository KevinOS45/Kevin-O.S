package com.example.pertemuan3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class DetailsHero extends AppCompatActivity {

    ImageView imageView;
    TextView judul, deskripsi;

    String datasatu, datadua;
    int iv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_hero);

        imageView = findViewById(R.id.detil_gambar);
        judul = findViewById(R.id.detil_judul);
        deskripsi = findViewById(R.id.detil_deskripsi);

        getData();
        setData();
    }

    private void getData(){
        if(getIntent().hasExtra("iv") && getIntent().hasExtra("datasatu") &&
        getIntent().hasExtra("datadua")){
            datasatu = getIntent().getStringExtra("datasatu");
            datadua = getIntent().getStringExtra("datadua");
            iv = getIntent().getIntExtra("iv", 1);
        }
        else {
            Toast.makeText(this,"NO Data", Toast.LENGTH_SHORT).show();
        }
    }

    private void setData(){
        judul.setText(datasatu);
        deskripsi.setText(datadua);
        imageView.setImageResource(iv);
    }
}
